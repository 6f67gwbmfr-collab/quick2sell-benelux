import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Alleen POST toegestaan" });
  }

  try {
    const { images = [], notes = "", mode = "analysis", report = "" } = req.body || {};

    if (mode === "ad") {
      const ad = await client.responses.create({
        model: "gpt-4.1-mini",
        input: [{
          role: "user",
          content: [{
            type: "input_text",
            text: `Je bent Quick2Sell Benelux, een professionele advertentie-copywriter voor Marktplaats, 2dehands en Vinted. Schrijf in het Nederlands een complete verkoopadvertentie op basis van dit rapport. Gebruik platte tekst, geen markdown. Maak drie varianten: Marktplaats, 2dehands en Vinted. Wees eerlijk over staat en gebreken.\n\nRapport:\n${report}`
          }]
        }],
        max_output_tokens: 1400
      });
      return res.status(200).json({ result: ad.output_text });
    }

    if (!Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ error: "Geen foto's ontvangen" });
    }

    const content = [
      {
        type: "input_text",
        text: `Je bent Quick2Sell Benelux: een professionele AI-verkoopassistent en tweedehands handelaar met 20 jaar ervaring op Marktplaats, 2dehands, Vinted, eBay en Facebook Marketplace. Analyseer de foto's van het product en geef een praktisch verkooprapport voor Nederland en België.\n\nExtra info van gebruiker: ${notes || "geen"}\n\nSchrijf in platte tekst, kort en scanbaar, met exact deze koppen:\n\n✅ IDENTIFICATIE\n- Product\n- Merk/model indien zichtbaar\n- Type\n- Kleur/materiaal\n- Staat\n- Beschadigingen/ontbrekende onderdelen\n- Zekerheid in procenten\n\n💰 BENELUX MARKTWAARDE\n- Snelle verkoopprijs\n- Ideale verkoopprijs\n- Maximale realistische vraagprijs\n- Geschatte nieuwprijs indien logisch\n- Vraag en aanbod\n\n⭐ QUICK2SELL SCORE\n- Score 1 t/m 5 sterren\n- Verkoopsnelheid\n- Winstpotentie\n- Populariteit\n\n📍 BESTE PLATFORM\n- Marktplaats NL\n- 2dehands BE\n- Vinted Benelux\n- Ophalen of verzenden\n\n🤝 ONDERHANDELSTRATEGIE\n- Startprijs\n- Minimale prijs\n- Reactie op laag bod\n\n📈 VERKOOPTIPS\n- Foto tips\n- Titel tips\n- Schoonmaak/reparatie tips\n\nSluit af met: 📝 Advertentie gereed? Nee, wacht op jouw goedkeuring.`
      }
    ];

    for (const img of images.slice(0, 5)) {
      content.push({
        type: "input_image",
        image_url: img
      });
    }

    const response = await client.responses.create({
      model: "gpt-4.1-mini",
      input: [{ role: "user", content }],
      max_output_tokens: 1800
    });

    return res.status(200).json({ result: response.output_text });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "AI-analyse mislukt", detail: err.message });
  }
}
